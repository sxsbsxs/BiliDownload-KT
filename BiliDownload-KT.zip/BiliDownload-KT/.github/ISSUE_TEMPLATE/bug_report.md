---
name: Bug report
about: Report a reproducible issue
title: "[Bug] "
labels: bug
---

## Environment
- Android version:
- App version:

## Steps to reproduce
1.
2.

## Expected behavior

## Actual behavior

## Logs (remove all cookies, tokens, and personal data)
